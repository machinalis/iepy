package com.machinalis.get_java_version;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
	public static void main(String[] args) {
		Pattern javaVersionPattern = Pattern.compile("^\\d+\\.(?<majorVersionNumber>\\d+).*$");
		Matcher javaVersionMatcher = javaVersionPattern.matcher(System.getProperty("java.version"));
		
		if (javaVersionMatcher.matches()) {
			System.out.println(javaVersionMatcher.group("majorVersionNumber"));
		} else {
			System.err.print("unknown");
			System.exit(-1);
		}
	}
}
